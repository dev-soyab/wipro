package com.wipro.bank.loans.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.bank.loans.dto.LoanReqDto;
import com.wipro.bank.loans.dto.LoanResDto;
import com.wipro.bank.loans.dto.ResponseDto;
import com.wipro.bank.loans.services.LoanServices;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api")
public class LoansRestController {

	@Autowired
	private LoanServices services;
	
	@PostMapping("/create")
	public ResponseEntity<?> createNewLoan(@RequestBody LoanReqDto loanReqDto) {
		ResponseDto responseDto = services.createNewLoan(loanReqDto);
		return ResponseEntity.status(HttpStatus.CREATED).body(responseDto);
	}
	
	@GetMapping("/fetch")
	public ResponseEntity<?> fetchLoan(@RequestParam String mobileNumber){
		LoanResDto loanResDto = services.fetchExistingLoan(mobileNumber);
		return ResponseEntity.status(HttpStatus.OK).body(loanResDto);
	}
	
	@PutMapping("/update")
	public ResponseEntity<?> updateLoan(@RequestBody LoanResDto loanResDto,@RequestParam long loanNumber){
		ResponseDto responseDto = services.updateExistingLoan(loanResDto,loanNumber);
		return ResponseEntity.status(HttpStatus.OK).body(responseDto);
	}
	
	@DeleteMapping("/delete")
	public ResponseEntity<?> deleteLoan(@RequestParam String mobileNumber){
		ResponseDto responseDto = services.deleteExistingLoan(mobileNumber);
		return ResponseEntity.status(HttpStatus.OK).body(responseDto);
	}
	
}

package com.wipro.bank.loans.mappers;

import com.wipro.bank.loans.dto.LoanReqDto;
import com.wipro.bank.loans.dto.LoanResDto;
import com.wipro.bank.loans.entities.Loans;

public class LoanMapper {
	public static Loans toLoan(LoanReqDto loanReqDto, Loans loan) {

		loan.setAmountPaid(loanReqDto.getAmountPaid());
		loan.setLoanType(loanReqDto.getLoanType());
		loan.setTotalLoan(loanReqDto.getTotalLoan());
		loan.setMobileNumber(loanReqDto.getMobileNumber());
		
		return loan;
	}

	public static LoanResDto toLoanResDto(Loans loanFound, LoanResDto loanResDto) {
		loanResDto.setAmountPaid(loanFound.getAmountPaid());
		loanResDto.setLoanNumber(loanFound.getLoanNumber());
		loanResDto.setLoanType(loanFound.getLoanType());
		loanResDto.setMobileNumber(loanFound.getMobileNumber());
		loanResDto.setTotalLoan(loanFound.getTotalLoan());
		loanResDto.setOutstandingAmount(loanFound.getOutstandingAmount());
		
		return loanResDto;
	}

}

package com.wipro.bank.loans.exceptions;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import com.wipro.bank.loans.dto.ErrorResponseDto;


@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(LoanAlreadyExistWithMobileNumber.class)
	public ResponseEntity<ErrorResponseDto> handleLoanAlreadyExistsExceptionWithMobileNumber(
			LoanAlreadyExistWithMobileNumber exception, WebRequest webRequest) {
		ErrorResponseDto errorResponseDTO = new ErrorResponseDto(webRequest.getDescription(false),
				HttpStatus.BAD_REQUEST, exception.getMessage(), LocalDateTime.now());
		return new ResponseEntity<>(errorResponseDTO, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(LoansNotFoundException.class)
	public ResponseEntity<ErrorResponseDto> handleLoansNotFoundException(LoansNotFoundException exception, WebRequest webRequest){
		ErrorResponseDto errorResponseDTO = new ErrorResponseDto(webRequest.getDescription(false),
				HttpStatus.NOT_FOUND, exception.getMessage(), LocalDateTime.now());
		return new ResponseEntity<>(errorResponseDTO, HttpStatus.NOT_FOUND);
	}
	
//	@ExceptionHandler(value = MethodArgumentNotValidException.class)
//	public ResponseEntity<?> handleValidationFailureException(MethodArgumentNotValidException ex){
//		//List<ObjectError> errorsList = ex.getBindingResult().getAllErrors();
//		List<FieldError> errorsList = ex.getBindingResult().getFieldErrors();
//		
//		Map<String, String> errorMap = new HashMap<String, String>();		
//		
//		for(FieldError error : errorsList) {
//			String fieldName = error.getField();
//			String msg = error.getDefaultMessage();
//			//System.out.println(fieldName + ": " + msg);
//			errorMap.put(fieldName, msg);
//		}
//		return new ResponseEntity<>(errorMap, HttpStatus.BAD_REQUEST);
//	}
	
//	@ExceptionHandler(value = UnexpectedTypeException.class)
//	public ResponseEntity<?> UnexpectedTypeException(UnexpectedTypeException ex){
//		//List<ObjectError> errorsList = ex.getBindingResult().getAllErrors();
//		List<FieldError> errorsList = ex.getBindingResult().getFieldErrors();
//		
//		Map<String, String> errorMap = new HashMap<String, String>();		
//		
//		for(FieldError error : errorsList) {
//			String fieldName = error.getField();
//			String msg = error.getDefaultMessage();
//			//System.out.println(fieldName + ": " + msg);
//			errorMap.put(fieldName, msg);
//		}
//		return new ResponseEntity<>(errorMap, HttpStatus.BAD_REQUEST);
//	}
}

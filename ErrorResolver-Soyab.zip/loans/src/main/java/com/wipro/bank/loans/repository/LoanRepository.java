package com.wipro.bank.loans.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wipro.bank.loans.entities.Loans;

@Repository
public interface LoanRepository extends JpaRepository<Loans, Integer> {

	public Optional<Loans> findByMobileNumber(String mobileNumber);

	public Optional<Loans> findByLoanNumber(long loanNumber);

}

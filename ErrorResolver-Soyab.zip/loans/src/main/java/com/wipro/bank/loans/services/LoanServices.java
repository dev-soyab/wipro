package com.wipro.bank.loans.services;

import org.springframework.stereotype.Service;

import com.wipro.bank.loans.dto.LoanReqDto;
import com.wipro.bank.loans.dto.LoanResDto;
import com.wipro.bank.loans.dto.ResponseDto;

@Service
public interface LoanServices {
	public ResponseDto createNewLoan(LoanReqDto loanReqDto);

	public LoanResDto fetchExistingLoan(String mobileNumber);

	public ResponseDto updateExistingLoan(LoanResDto loanResDto, long loanNumber);

	public ResponseDto deleteExistingLoan(String mobileNumber);
}

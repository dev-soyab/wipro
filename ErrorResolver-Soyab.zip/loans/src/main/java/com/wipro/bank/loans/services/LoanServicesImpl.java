package com.wipro.bank.loans.services;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.wipro.bank.loans.constants.LoanConstants;
import com.wipro.bank.loans.dto.LoanReqDto;
import com.wipro.bank.loans.dto.LoanResDto;
import com.wipro.bank.loans.dto.ResponseDto;
import com.wipro.bank.loans.entities.Loans;
import com.wipro.bank.loans.exceptions.LoanAlreadyExistWithMobileNumber;
import com.wipro.bank.loans.exceptions.LoansNotFoundException;
import com.wipro.bank.loans.mappers.LoanMapper;
import com.wipro.bank.loans.repository.LoanRepository;

@Service
public class LoanServicesImpl implements LoanServices {

	@Autowired
	private LoanRepository loanRepo;
	
	@Override
	public ResponseDto createNewLoan(LoanReqDto loanReqDto) {
		
		Optional<Loans> loanOpt = loanRepo.findByMobileNumber(loanReqDto.getMobileNumber());
		if(loanOpt.isPresent()) {
			throw new LoanAlreadyExistWithMobileNumber("Loan already registered with given mobileNumber: " + loanReqDto.getMobileNumber());
			
		}
		else {
			Loans loan = LoanMapper.toLoan(loanReqDto, new Loans());
			long randomLoanNumber = 100000000000L + new Random().nextInt(900000000);
			loan.setLoanNumber(randomLoanNumber);
			loan.setOutstandingAmount(loan.getTotalLoan()-loan.getAmountPaid());
			loan.setCreatedBy("Soyab");
			loan.setCreatedAt(LocalDateTime.now());
			
			loanRepo.save(loan);
			return new ResponseDto(LoanConstants.STATUS_201,LoanConstants.MESSAGE_201);
		}
	}

	@Override
	public LoanResDto fetchExistingLoan(String mobileNumber) {
		Optional<Loans> loanOpt = loanRepo.findByMobileNumber(mobileNumber);	
		if(loanOpt.isPresent()) {
			Loans loanFound = loanOpt.get();
			LoanResDto loanResDto = LoanMapper.toLoanResDto(loanFound,new LoanResDto());
			return loanResDto;
		}
		else {
			throw new LoansNotFoundException("No Loan registered with given mobileNumber: " + mobileNumber);
		}
	}

	@Override
	public ResponseDto updateExistingLoan(LoanResDto loanResDto, long loanNumber) {
		Optional<Loans> loanOpt = loanRepo.findByLoanNumber(loanNumber);	
		if(loanOpt.isPresent()) {
			Loans loanExisting = loanOpt.get();
			loanExisting.setAmountPaid(loanResDto.getAmountPaid());
			loanExisting.setLoanType(loanResDto.getLoanType());
			loanExisting.setMobileNumber(loanResDto.getMobileNumber());
			loanExisting.setTotalLoan(loanResDto.getTotalLoan());
			loanExisting.setOutstandingAmount(loanResDto.getOutstandingAmount());
			loanExisting.setUpdatedBy("Soyab");
			loanExisting.setUpdatedAt(LocalDateTime.now());
			
			loanRepo.save(loanExisting);
			return new ResponseDto(LoanConstants.STATUS_200,LoanConstants.MESSAGE_200);
		}
		else {
			throw new LoansNotFoundException("No Loan registered with given loanNumber: " + loanResDto.getLoanNumber());
		}
	}

	@Override
	public ResponseDto deleteExistingLoan(String mobileNumber) {
		Optional<Loans> loanOpt = loanRepo.findByMobileNumber(mobileNumber);
		if(loanOpt.isPresent()) {
			loanRepo.delete(loanOpt.get());
			return new ResponseDto(LoanConstants.STATUS_200,"Loan Deleted Successfully");
		}
		else {
			throw new LoansNotFoundException("No Loan registered with the given mobileNumber: " + mobileNumber);
		}
	}

	

}

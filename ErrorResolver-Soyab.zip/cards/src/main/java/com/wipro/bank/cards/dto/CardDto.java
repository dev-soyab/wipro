package com.wipro.bank.cards.dto;


import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor

public class CardDto {

//	@NotNull(message="mobileNumber has to be provided")
//	@Pattern(regexp = "(^$|[0-9]{10})", message = "Mobile Number must be of 10 digits")
	private Long mobileNumber;
	
	
//	@NotNull(message="cardType has to be provided")
	private String cardType;
	
//	@NotNull(message="totalLimit has to be provided")
	private int totalLimit;
	
//	@NotNull(message="amountUsed has to be provided")
	private int amountUsed;

	@NotNull(message="availableAmount has to be provided")
	private int availableAmount;
}

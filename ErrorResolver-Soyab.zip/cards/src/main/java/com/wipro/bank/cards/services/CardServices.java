package com.wipro.bank.cards.services;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.bank.cards.dto.CardDto;
import com.wipro.bank.cards.dto.CardDtoResponse;
import com.wipro.bank.cards.dto.ResponseDto;
import com.wipro.bank.cards.entities.Card;
import com.wipro.bank.cards.exceptions.CardNotFoundException;
import com.wipro.bank.cards.mappers.CardMapper;
import com.wipro.bank.cards.repository.CardRepository;

@Service
public class CardServices {
	
	@Autowired
	private CardRepository cardRepo;
	
	public boolean newCard(CardDto cardDto) {
		Card card = CardMapper.toCard(cardDto, new Card());
		
		Optional<Card> cardOpt = cardRepo.findByMobileNumber(card.getMobileNumber());
		
		if(cardOpt.isPresent()) {
			return false;
		}	
		else {
			long randomCardNumber = 100000000000L + new Random().nextInt(900000000);
			card.setCardNumber(randomCardNumber);
			card.setCreatedBy("Soyab");
			card.setCreatedAt(LocalDateTime.now());
			cardRepo.save(card);
			return true;
		}
	}

	public CardDtoResponse fetchCardByMobileNumber(long mobileNumber) {
		Optional<Card> cardOpt = cardRepo.findByMobileNumber(mobileNumber);
		if(cardOpt.isPresent()) {
			return CardMapper.toCardDto(new CardDtoResponse(), cardOpt.get());
		}
		else {
			throw new CardNotFoundException("Card not found with the given input data mobileNumber: " + mobileNumber);
		}
	}

	
	public CardDtoResponse fetchCardByCardNumber(long cardNumber) {
		Optional<Card> cardOpt = cardRepo.findByCardNumber(cardNumber);
		if(cardOpt.isPresent()) {
			return CardMapper.toCardDto(new CardDtoResponse(), cardOpt.get());
		}
		else {
			throw new CardNotFoundException("Card not found with the given input data cardNumber: " + cardNumber);
		}
	}

	public boolean updateCard(CardDto cardDto,long cardNumber) {
		Optional<Card> cardOpt = cardRepo.findByCardNumber(cardNumber);
		if(cardOpt.isPresent()) {
			Card card = CardMapper.toCard(cardDto, new Card());
			card.setCardId(cardOpt.get().getCardId());
			card.setUpdatedBy("Soyab");
			card.setUpdatedAt(LocalDateTime.now());
			cardRepo.save(card);
			return true;
		}
		else {
			throw new CardNotFoundException("Card not found with the given input data cardNumber: " + cardNumber);
		}
	}

	
	public boolean deleteCard(long mobileNumber) {
		Optional<Card> cardOpt = cardRepo.findByMobileNumber(mobileNumber);
		if(cardOpt.isPresent()) {
			cardRepo.delete(cardOpt.get());
			return true;
		}
		else {
			throw new CardNotFoundException("Card not found with the given input data mobileNumber: " + mobileNumber);
		}
	}
	
}

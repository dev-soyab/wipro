package com.wipro.bank.cards.controller;

import javax.print.attribute.standard.Media;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.bank.cards.clients.AccountFeignClient;
import com.wipro.bank.cards.clients.LoanFeignClients;
import com.wipro.bank.cards.dto.AccountsDTO;
import com.wipro.bank.cards.dto.CardDtoResponse;
import com.wipro.bank.cards.dto.CustomerDTO;
import com.wipro.bank.cards.dto.CustomerDetailsDto;
import com.wipro.bank.cards.dto.LoanResDto;
import com.wipro.bank.cards.repository.CardRepository;
import com.wipro.bank.cards.services.CardServices;

import jakarta.annotation.Generated;
import jakarta.ws.rs.core.MediaType;

@RestController
@RequestMapping(path ="/api")
public class CustomerDetailsController {
	
	@Autowired
	private LoanFeignClients loanClient;
	
//	@Autowired
//	private AccountFeignClient accountClient;
	
	@Autowired
	private CardServices services;
	
	@GetMapping("/fetchCustomerDetails")
	public ResponseEntity<CustomerDetailsDto> fetchAllDetails(@RequestParam String mobileNumber){
		LoanResDto loan = loanClient.fetchLoan(mobileNumber).getBody();
		CardDtoResponse card = services.fetchCardByMobileNumber(Long.parseLong(mobileNumber));
//		ResponseEntity<?> res = accountClient.fetchAccountDetails(mobileNumber);
//		if(res.getBody().getClass().getSimpleName().equals("CustomerDTO")) {
		AccountsDTO account = new AccountsDTO(1632683751L,"Savings","Haridwar, Uttarkhand");
		CustomerDTO customer = new CustomerDTO("Salman Khan","abrahamx@gmail.com","9988776655",account);
			
			CustomerDetailsDto customerDetailsDto = new CustomerDetailsDto(card,loan,customer);
			
//			CustomerDetailsDto customerDetailsDto = new CustomerDetailsDto(card,loan);
			
			return ResponseEntity.status(HttpStatus.OK).body(customerDetailsDto);
		
	}
}

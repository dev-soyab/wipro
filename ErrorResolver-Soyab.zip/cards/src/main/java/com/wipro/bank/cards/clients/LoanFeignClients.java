package com.wipro.bank.cards.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.wipro.bank.cards.dto.LoanResDto;



@FeignClient("loans")
public interface LoanFeignClients {
	@GetMapping(value = "/api/fetch",consumes = "application/json")
	public ResponseEntity<LoanResDto> fetchLoan(@RequestParam String mobileNumber);
}

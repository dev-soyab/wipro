package com.wipro.bank.cards.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.wipro.bank.cards.dto.CustomerDTO;

//@FeignClient("accounts")
public interface AccountFeignClient {

//	@GetMapping("/api/fetch")
//	public ResponseEntity<CustomerDTO> fetchAccountDetails(@RequestParam String mobileNumber);
}

package com.wipro.bank.cards.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.bank.cards.constants.CardConstants;
import com.wipro.bank.cards.dto.CardDto;
import com.wipro.bank.cards.dto.CardDtoResponse;
import com.wipro.bank.cards.dto.ResponseDto;
import com.wipro.bank.cards.exceptions.CardAlreadyExistWithMobileNumber;
import com.wipro.bank.cards.exceptions.CardNotFoundException;
import com.wipro.bank.cards.services.CardServices;

import jakarta.validation.Valid;

@RestController
//@RequestMapping("/cards/api")
public class CardContoller {
	
	@Autowired
	private CardServices services;
	
	@PostMapping("/cards/api/create")
	public ResponseEntity<?> createNewCard(@RequestBody CardDto cardDto){
		boolean status = services.newCard(cardDto);
		if(status) {
			return ResponseEntity.status(HttpStatus.CREATED).body(new ResponseDto("201",CardConstants.MESSAGE_201));
		}
		else {
			throw new CardAlreadyExistWithMobileNumber("Card already registered with given mobileNumber " + cardDto.getMobileNumber());
			}	
	}
	

	@RequestMapping(value = "/cards/api/fetch",params={"mobileNumber"})
	public ResponseEntity<?> fetchCardDetailsByMobileNumber(@RequestParam("mobileNumber") long mobileNumber){
		CardDtoResponse cardDtoRes = services.fetchCardByMobileNumber(mobileNumber);
		return ResponseEntity.status(HttpStatus.OK).body(cardDtoRes);
	}
	

	@RequestMapping(value = "/cards/api/fetch",params={"cardNumber"})
	public ResponseEntity<?> fetchCardDetailsByCardNumber(@RequestParam("cardNumber") long cardNumber){
		CardDtoResponse cardDtoRes = services.fetchCardByCardNumber(cardNumber);
		return ResponseEntity.status(HttpStatus.OK).body(cardDtoRes);
	}
	
	@PutMapping("/cards/api/update")
	public ResponseEntity<?> updateCardDetails(@RequestBody CardDto cardDto,@RequestParam long cardNumber){
		boolean status = services.updateCard(cardDto,cardNumber);
		if(status) {
			return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto(CardConstants.STATUS_200,CardConstants.MESSAGE_200));
		}
		else {
			throw new CardNotFoundException("Card not found with the given input data cardNumber: " + cardNumber);
		}	
	}
	
	@DeleteMapping("/cards/api/delete")
	public ResponseEntity<?> deleteCardDetails(@RequestParam long mobileNumber){
		boolean status = services.deleteCard(mobileNumber);
		if(status) {
			return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto(CardConstants.STATUS_200,"Request Processed Successfully"));
		}
		else {
			throw new CardNotFoundException("Card not found with the given input data mobileNumber: " + mobileNumber);
		}
	}
	
}

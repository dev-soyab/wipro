package com.wipro.bank.cards.dto;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class CustomerDTO {
	

	//	
//	@NotEmpty(message = "Name cannot be null or empty")
	private String name;
	
//	@NotEmpty(message = "Mail cannot be null or empty")
//	@Email(message = "email should be valid")
	private String mail;
	
//	@Column(name = "mobile_number")
//	@Pattern(regexp = "(^$|[0-9]{10})", message = "Mobile Number must be of 10 digits")
	private String mobileNumber;
	
	private AccountsDTO accountDTO;
	
	public CustomerDTO(String name, String mail, String mobileNumber, AccountsDTO accountDTO) {
		super();
		this.name = name;
		this.mail = mail;
		this.mobileNumber = mobileNumber;
		this.accountDTO = accountDTO;
	}
}

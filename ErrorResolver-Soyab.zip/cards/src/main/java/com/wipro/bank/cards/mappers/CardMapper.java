package com.wipro.bank.cards.mappers;

import com.wipro.bank.cards.dto.CardDto;
import com.wipro.bank.cards.dto.CardDtoResponse;
import com.wipro.bank.cards.entities.Card;

public class CardMapper {

	public static Card toCard(CardDto cardDto, Card card) {

		card.setCardType(cardDto.getCardType());
		card.setAmountUsed(cardDto.getAmountUsed());
		card.setAvailableAmount(cardDto.getAvailableAmount());
		card.setMobileNumber(cardDto.getMobileNumber());
		card.setTotalLimit(cardDto.getTotalLimit());

		return card;
	}

	public static CardDtoResponse toCardDto(CardDtoResponse cardDtoResponse, Card card) {

		cardDtoResponse.setCardType(card.getCardType());
		cardDtoResponse.setAmountUsed(card.getAmountUsed());
		cardDtoResponse.setAvailableAmount(card.getAvailableAmount());
		cardDtoResponse.setMobileNumber(card.getMobileNumber());
		cardDtoResponse.setTotalLimit(card.getTotalLimit());
		cardDtoResponse.setCardNumber(card.getCardNumber());

		return cardDtoResponse;
	}
	
}

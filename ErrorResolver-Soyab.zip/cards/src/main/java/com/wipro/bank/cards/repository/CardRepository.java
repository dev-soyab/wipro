package com.wipro.bank.cards.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wipro.bank.cards.entities.Card;

@Repository
public interface CardRepository extends JpaRepository<Card, Integer> {

	Optional<Card> findByMobileNumber(long mobileNumber);

	Optional<Card> findByCardNumber(long cardNumber);

}

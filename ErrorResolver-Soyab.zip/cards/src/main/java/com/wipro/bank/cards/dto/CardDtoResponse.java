package com.wipro.bank.cards.dto;

import com.wipro.bank.cards.entities.Card;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CardDtoResponse {
	private Long mobileNumber;

	private String cardType;
	
	private Long cardNumber;
	
	private int totalLimit;

	private int amountUsed;

	private int availableAmount;
}

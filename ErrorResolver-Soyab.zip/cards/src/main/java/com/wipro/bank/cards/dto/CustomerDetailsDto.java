package com.wipro.bank.cards.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

public class CustomerDetailsDto {
	
	private CardDtoResponse card;
	private LoanResDto loan;
	private CustomerDTO customer;
	public CustomerDetailsDto(CardDtoResponse card, LoanResDto loan, CustomerDTO customer) {
		super();
		this.card = card;
		this.loan = loan;
		this.customer = customer;
	}
	public CustomerDetailsDto(CardDtoResponse card, LoanResDto loan) {
		super();
		this.card = card;
		this.loan = loan;
	}
	
	
}
